alter table {schema}.ponto_cotado alter column valor_classifica_las type varchar(10) using valor_classifica_las::varchar(10);
alter table {schema}.ponto_cotado drop constraint if exists valor_classifica_las_id;
alter table {schema}.ponto_cotado add constraint valor_classifica_las_id foreign key (valor_classifica_las) references {schema}.valor_classifica_las(identificador);
