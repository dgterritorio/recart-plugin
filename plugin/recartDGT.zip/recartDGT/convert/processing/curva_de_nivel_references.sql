alter table {schema}.curva_de_nivel alter column valor_tipo_curva type varchar(10) using valor_tipo_curva::varchar(10);
alter table {schema}.curva_de_nivel drop constraint if exists valor_tipo_curva_id;
alter table {schema}.curva_de_nivel add constraint valor_tipo_curva_id foreign key (valor_tipo_curva) references {schema}.valor_tipo_curva(identificador);
