alter table {schema}.linha_de_quebra alter column valor_classifica type varchar(10) using valor_classifica::varchar(10);
alter table {schema}.linha_de_quebra drop constraint if exists valor_classifica_id;
alter table {schema}.linha_de_quebra add constraint valor_classifica_id foreign key (valor_classifica) references {schema}.valor_classifica(identificador);

alter table {schema}.linha_de_quebra alter column valor_natureza_linha type varchar(10) using valor_natureza_linha::varchar(10);
alter table {schema}.linha_de_quebra drop constraint if exists valor_natureza_linha_id;
alter table {schema}.linha_de_quebra add constraint valor_natureza_linha_id foreign key (valor_natureza_linha) references {schema}.valor_natureza_linha(identificador);
