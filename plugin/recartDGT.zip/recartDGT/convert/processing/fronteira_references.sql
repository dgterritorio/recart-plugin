alter table {schema}.fronteira alter column valor_estado_fronteira type varchar(10) using valor_estado_fronteira::varchar(10);
alter table {schema}.fronteira drop constraint if exists valor_estado_fronteira_id;
alter table {schema}.fronteira add constraint valor_estado_fronteira_id foreign key (valor_estado_fronteira) references {schema}.valor_estado_fronteira(identificador);
