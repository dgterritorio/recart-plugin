alter table {schema}.designacao_local alter column valor_local_nomeado type varchar(10) using valor_local_nomeado::varchar(10);
alter table {schema}.designacao_local drop constraint if exists valor_local_nomeado_id;
alter table {schema}.designacao_local add constraint valor_local_nomeado_id foreign key (valor_local_nomeado) references {schema}.valor_local_nomeado(identificador);
