dc = {
    "locale": "latin1",
    "ndd": "ndd1",
    "schema": "rel",
    "save_src": True,
    "post-processing": [
        {
            "op": "polygonize",
            "layers": []
        },
        {
            "op": "to3D",
            "layers": []
        },
        {
            "op": "to2D",
            "layers": []
        }
    ]
}
